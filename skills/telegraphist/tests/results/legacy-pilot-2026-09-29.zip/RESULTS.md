# Telegraphist: implementation and raw OpenRouter pilot

Completed 2026-09-29. **96/96 real generation calls; US$0.1293862.** Exact dedicated-key usage reconciled; key disabled. No transport failures, truncations, missing token accounting or unknown charges.

## Decision

The package works and is available for opt-in use. **Do not claim net savings or enable it globally based on this pilot.** Both models shortened their answers, but loading the full skill cost more than the output savings on these short tasks. Cost per combined pass also increased. Longer tasks, multi-turn amortization, the one-line concision control and Caveman were not tested.

## Delivered

- `comunicacao-telegrafica` renamed to `telegraphist`; catalog links updated.
- English, telegraphic core; familiar symbols for clear, token-cheaper relations. Negation, uncertainty, conditions, temporal scope, exact literals and requested detail take precedence over brevity.
- `TESTS.md`: reproducible methodology, measured results and limitations.
- `scripts/bench.py`: standalone raw OpenRouter runner, frozen inputs, capped budget, append-only evidence and conservative resume behavior.
- `scripts/pack.py`: standard-library JSON whitespace compaction, exact numeric/string bytes, duplicate/nonstandard input rejection, 10 MiB input cap, no appended newline. No model calls or extra dependency.
- 29 offline tests passed. Independent source review found no remaining blockers in the documented single-process, trusted-local scope.

## Economic results

Full skill and message framing included in input tokens. Values below are native API accounting, not local tokenizer estimates.

| Model | Arm | Calls | Input | Output | Total tokens | Cost USD | Latency p50 / p95 seconds |
|---|---|---:|---:|---:|---:|---:|---:|
| GPT-4.1 Mini | Baseline | 24 | 2,200 | 1,570 | 3,770 | 0.0033920 | 1.349 / 2.214 |
| GPT-4.1 Mini | Telegraphist | 24 | 11,080 | 1,177 | 12,257 | 0.0063152 | 1.237 / 2.099 |
| Claude Sonnet 4.5 | Baseline | 24 | 2,418 | 3,207 | 5,625 | 0.055359 | 3.098 / 9.727 |
| Claude Sonnet 4.5 | Telegraphist | 24 | 12,570 | 1,774 | 14,344 | 0.064320 | 2.476 / 8.481 |

| Model | Output reduction | Total-token increase | Cost increase | Native added input / request |
|---|---:|---:|---:|---:|
| GPT-4.1 Mini | 25.03% | 225.12% | 86.18% | 370 tokens |
| Claude Sonnet 4.5 | 44.68% | 155.00% | 16.19% | 423 tokens |

All 48 paired comparisons have complete accounting. Descriptive task-cluster bootstrap intervals (5,000 resamples, repetitions retained within tasks) are in `results.json`. They are not a powered equivalence test. Returned cache-read, cache-write and reasoning tokens were zero for all 96 responses; this does not reveal undocumented provider-internal processing.

## Correctness: separate evaluators

| Model | Arm | Strict JSON pass / 12 | Single-LLM semantic pass / 12 | Combined pass / 24 | Cost / combined pass USD |
|---|---|---:|---:|---:|---:|
| GPT-4.1 Mini | Baseline | 2 | 9 | 11 | 0.00030836 |
| GPT-4.1 Mini | Telegraphist | 4 | 10 | 14 | 0.00045109 |
| Claude Sonnet 4.5 | Baseline | 0 | 9 | 9 | 0.006151 |
| Claude Sonnet 4.5 | Telegraphist | 0 | 10 | 10 | 0.006432 |

Strict JSON requires the entire response to be JSON. **42/48 structured answers failed the requested format**, not the transport. A post-hoc diagnostic removes one enclosing JSON fence: 40 of those 42 then match the expected typed values exactly. The other two contain additional prose plus a fenced query result. These are not evidence of 42 factual mistakes; they also cannot be retroactively counted as primary contract passes.

The separate blinded LLM review accepted **38/48 free-text answers**, flagged ten requirement/fidelity failures and no violations of the predefined critical criteria. The reviewer received prompts, frozen rubrics and shuffled opaque-ID answers, not model/arm mappings. Reviewer: `gpt-6-astra` via `openai-codex`, one LLM judge, not a human. Style can reveal treatment. No separate OpenRouter judge calls were made; reviewer-harness costs are not included in the measured generation spend.

Flags included confusing an attempt with only the first try, strengthening a risk warning, changing an untrusted instruction into an allegation, and confirming a restore-verification process instead of requiring verified recoverability. Some distinctions require judgment. Exact answers, rubric scores and reasons are retained; there was no human adjudication or inter-rater study. The combined metric mixes deterministic contract checks and subjective review, so it is a descriptive estimate, not established ground-truth accuracy.

## Protocol

Twelve fixed tasks, six English and six Portuguese; two model families; two repetitions; baseline/full-skill arms. Tasks cover extraction, conditions, retries, JSON fidelity, a supplied SQL query, missing evidence, temporal scope, operational summary, requested explanatory detail, quoted untrusted instructions, deletion safety and uncertainty. SQL was evaluated logically; no generated code or SQL was executed.

Direct HTTPS to OpenRouter, without an agent SDK, AGENTS.md, SOUL, memory, retrieval, previous answers or tools. Payloads contain only neutral instructions, the task and the exact full skill in the treatment arm. Expected answers and rubrics are excluded from generation payloads.

Routes: `openai/gpt-4.1-mini` via `openai`; `anthropic/claude-sonnet-4.5` via `anthropic`. Fallbacks disabled; supported parameters required. Temperature 0, output cap 2,048, Anthropic reasoning disabled, OpenAI reasoning unsupported/omitted. Temperature zero does not imply deterministic provider execution. Randomized blocks and arm order use seed 20260929. Underlying dated model metadata is preserved in the selected generation audit.

A non-resetting US$10 dedicated key and US$0.10 per-request client reservation bounded the sequential run. Exactly 96 generation submissions; no automatic retries. All responses retained, including wrong or fenced answers. API request/response records and historical snapshots are unchanged.

Full skill SHA-256: `9be5d126b5d8fb3d8188e49babcf66950df4baedd533c73ebcbfd88bc22a2f04`.

## Separate deterministic tool measurement

A four-record JSON example measured **142 to 82 tokens (42.25% reduction)** with `tiktoken 0.14.0` / `o200k_base`, with typed round-trip and idempotence verified. This is preprocessing without an LLM, not an end-to-end benchmark or a universal saving. Exact input/output are in `pack-measurement.json`.

The complete skill itself measures 366 local tokens in both `cl100k_base` and `o200k_base`; native input overhead differs because model tokenizers and message framing differ. A visible symbol is not necessarily one token. Local counts do not replace native billing.

## Version differences and limitations

The historical runner was frozen before generation. Independent review after generation started found defensive-validation gaps. Repository code was hardened separately; the original snapshot and manifest were not rewritten. A post-run independent audit verified all 96 original payloads, routes, usage fields, costs, reservations and generation metadata, so no candidate was regenerated or replaced. Future runs should use the current repository runner, not the historical snapshot.

A setup-only HTTP-status handling error was recovered before generation; an unused credential was disabled. It produced no extra generation calls or candidate changes. Account-level and credential details are excluded from public evidence.

The pilot is small, hand-authored and not a held-out production sample. Repetitions are not independent new tasks. No two-percentage-point non-inferiority conclusion, superiority over Caveman, real agent tool-use benefit or universal losslessness is established. The larger study was not run.

## Evidence package

- Frozen skill, fixtures, protocol, runner, catalog/route snapshots and manifest.
- Exact request/response log; selected read-only generation metadata with private identifiers omitted.
- Economic aggregates, paired intervals, strict-format diagnostic and combined quality summary.
- Blinded packet, identity mapping, individual judgments and reviewer-method disclosure.
- Independent audit, scoped accounting reconciliation and local tool measurements.
- `SHA256SUMS.json` covers packaged bytes. Credentials, account balances, account/session/workspace identifiers, local supervisor and delivery files are excluded.
