"""Read-only, independent audit of the completed frozen pilot. No API calls."""
from collections import Counter, defaultdict
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).parent
protocol = json.loads((ROOT / 'protocol.json').read_text())
manifest = json.loads((ROOT / 'manifest.json').read_text())
for name, digest in manifest.items():
    assert Path(name).name == name
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
spec = importlib.util.spec_from_file_location('frozen_runner', ROOT / 'bench.snapshot.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
records = [json.loads(line) for line in (ROOT / 'attempts.jsonl').read_text().splitlines()]
starts = [r for r in records if r['event'] == 'start']
results = [r for r in records if r['event'] == 'result']
slots = {s['id']: s for s in protocol['slots']}
tasks = {t['id']: t for t in protocol['tasks']}
routes = {r['model']: r for r in protocol['routes']}
fixtures = [json.loads(line) for line in (ROOT / 'cases.jsonl').read_text().splitlines()]
assert fixtures == protocol['tasks']
assert len(tasks) == 12 and len(routes) == 2
assert len(slots) == len(starts) == len(results) == 96
assert Counter(r['slot'] for r in starts) == Counter(slots.keys())
assert Counter(r['slot'] for r in results) == Counter(slots.keys())
start_map = {r['slot']: r for r in starts}
skill = (ROOT / 'SKILL.snapshot.md').read_text()
groups = defaultdict(lambda: dict(count=0, prompt_tokens=0, completion_tokens=0,
                                 total_tokens=0, cost=Decimal(0), scored_pass=0,
                                 scored_fail=0, unscored=0))
ids = set()
for result in results:
    slot = slots[result['slot']]
    route = routes[slot['model']]
    assert start_map[result['slot']]['payload'] == runner.payload(slot, tasks[slot['task']], route, skill)
    assert result['http_status'] == 200 and result['protocol_error'] is None
    response = result['raw_response']
    assert response['model'] == slot['model']
    assert response['provider'] == route['observed_provider']
    assert response['id'] and response['id'] not in ids
    ids.add(response['id'])
    assert len(response['choices']) == 1
    choice = response['choices'][0]
    assert choice['finish_reason'] == result['finish_reason']
    assert choice['finish_reason'] in {'stop', 'length', 'content_filter'}
    assert isinstance(choice['message'], dict)
    usage = response['usage']
    assert usage == result['usage']
    for key in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
        assert type(usage[key]) is int and usage[key] >= 0
    assert usage['total_tokens'] == usage['prompt_tokens'] + usage['completion_tokens']
    cost = Decimal(str(usage['cost']))
    assert cost.is_finite() and cost >= 0
    assert cost == Decimal(result['cost'])
    assert cost <= Decimal(protocol['reserve_per_request'])
    score = runner.score(tasks[slot['task']], choice['message'].get('content'), choice['finish_reason'])
    assert score == result['score']
    group = groups[slot['model'] + '|' + slot['arm']]
    group['count'] += 1
    for key in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
        group[key] += usage[key]
    group['cost'] += cost
    group[{'pass': 'scored_pass', 'fail': 'scored_fail', 'unscored': 'unscored'}[score['status']]] += 1
assert sum(g['cost'] for g in groups.values()) <= Decimal(protocol['budget']) <= Decimal('10')
for group in groups.values():
    group['cost'] = str(group['cost'])
report = dict(verified=True, logical_slots=96, unique_generations=len(ids),
              exact_payloads_verified=True, frozen_hashes_verified=True,
              native_usage_verified=True, reservation_overruns=0,
              fixture_protocol_equality=True, groups=dict(groups),
              limitation='Semantic free-text quality remains separate from this deterministic audit.')
(ROOT / 'independent-audit.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
