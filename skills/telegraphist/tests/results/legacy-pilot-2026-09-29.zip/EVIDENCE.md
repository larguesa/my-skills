# Evidence and offline verification

Start with `RESULTS.md`. `results.json` contains economic aggregates and descriptive task-cluster intervals; `quality-summary.json` separates strict JSON checks from one blinded LLM review. No human adjudication is claimed.

`attempts.jsonl` contains exact original generation payloads and responses. `bench.snapshot.py`, `SKILL.snapshot.md`, `cases.jsonl`, `protocol.json` and catalog snapshots reproduce the historical inputs; their original hashes are in `manifest.json`. Do not use the historical runner for a new paid run: use the hardened repository `scripts/bench.py` and obtain a new explicit authorization and capped key.

From the extracted evidence directory, `python3 audit_pilot.py` independently checks all 96 slots, payloads, original hashes, token/cost accounting and deterministic scores without network calls. It writes `independent-audit.json`. `python3 merge_review.py` verifies the 48 review IDs, rubric arithmetic and word counts, then regenerates combined estimates without altering candidate logs. It writes the quality summary and updates the separate summary JSON; it does not change original validator records.

The blinded review packet omits identities. The separate mapping joins opaque IDs back to slots. Review reasons remain available for audit; the review is subjective and style may reveal treatment.

`generation-audit-public.json` includes only selected provider/model, native-token, cost, timing and finish fields from read-only generation lookups. Account, workspace, external-user, session and upstream-request metadata are excluded. Full originals remain private. `accounting-summary.json` reconciles response charges with the disabled dedicated key; it contains no account balance or credentials.

`code-review-public.json` records the final 29-test pass and reviewed current-source hashes. The current source is in the repository or outer delivery package, not the older snapshot. `pack-measurement.json` and `local-tokenization.json` are local non-LLM examples, not API billing or accuracy results.

`SHA256SUMS.json` hashes every other archive member. No secret files, account-wide billing preflight, local supervisor, internal delivery scripts, runtime logs or caches are included. Candidate and fixture text may be Portuguese because the pilot is bilingual; package instructions are English.
