#!/usr/bin/env python3
"""Isolated, standard-library OpenRouter pilot. No agent-context discovery."""
import random
import json
import os
import argparse
import hashlib
import time
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

NEUTRAL = 'Complete the user task accurately. Follow its requested language and output format.'


def payload(slot, task, route, skill):
    messages = [{'role': 'system', 'content': NEUTRAL}]
    if slot['arm'] == 'skill':
        messages.append({'role': 'system', 'content': skill})
    messages.append({'role': 'user', 'content': task['prompt']})
    result = dict(model=slot['model'], messages=messages, temperature=0,
                  max_tokens=2048, stream=False,
                  provider=dict(only=[route['provider']], allow_fallbacks=False,
                                require_parameters=True))
    if 'reasoning' in route:
        result['reasoning'] = route['reasoning']
    if 'max_price' in route:
        result['provider']['max_price'] = route['max_price']
    return result


def strict_json(text):
    def pairs(items):
        out = {}
        for k, v in items:
            if k in out:
                raise ValueError('duplicate key')
            out[k] = v
        return out
    def bad_constant(value):
        raise ValueError('nonfinite JSON')
    return json.loads(text, object_pairs_hook=pairs, parse_constant=bad_constant)


def typed_equal(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(typed_equal(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(typed_equal(x, y) for x, y in zip(a, b))
    return a == b


def score(task, text, finish):
    if finish == 'length':
        return dict(status='fail', reason='truncated')
    if not isinstance(text, str) or not text.strip():
        return dict(status='fail', reason='empty_or_refused')
    if 'expected' not in task:
        return dict(status='unscored', reason='human_review_pending')
    try:
        good = typed_equal(strict_json(text), task['expected'])
        return dict(status='pass' if good else 'fail', reason='typed_json_equality')
    except (ValueError, TypeError):
        return dict(status='fail', reason='invalid_json')


def can_spend(used, reserve, limit):
    try:
        used, reserve, limit = map(lambda x: Decimal(str(x)), (used, reserve, limit))
        return all(x.is_finite() and x >= 0 for x in (used, reserve, limit)) and used + reserve <= limit <= 10
    except (InvalidOperation, TypeError, ValueError):
        return False


def append(path, row):
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n')
        f.flush()
        os.fsync(f.fileno())


def rows(path):
    return [strict_json(line) for line in path.read_text().splitlines()] if path.exists() else []


def started(path):
    return {r['slot'] for r in rows(path)}


def schedule(tasks, routes, seed):
    rng = random.Random(seed)
    blocks = [(t['id'], r['model'], n) for t in tasks for r in routes for n in range(2)]
    rng.shuffle(blocks)
    slots = []
    for task, model, repeat in blocks:
        arms = ['baseline', 'skill']
        rng.shuffle(arms)
        for arm in arms:
            slots.append(dict(id=f'{task}|{model}|{repeat}|{arm}', task=task,
                              model=model, repeat=repeat, arm=arm))
    return slots


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def freeze(root, config):
    if (root/'manifest.json').exists():
        raise ValueError('Already frozen; use a new artifact directory')
    config = dict(config, version='telegraphist-pilot-v1', frozen_at=utc())
    config['slots'] = schedule(config['tasks'], config['routes'], 20260929)
    if len(config['slots']) != 96 or len({s['id'] for s in config['slots']}) != 96:
        raise ValueError('Expected 96 unique slots')
    save(root/'protocol.json', config)
    (root/'bench.snapshot.py').write_bytes(Path(__file__).read_bytes())
    names = ['SKILL.snapshot.md', 'cases.jsonl', 'protocol.json', 'bench.snapshot.py']
    names += [p.name for p in root.glob('*.endpoints.json')]
    if (root/'catalog.json').exists():
        names.append('catalog.json')
    save(root/'manifest.json', {name:digest(root/name) for name in names})


def verify(root):
    for name, expected in strict_json((root/'manifest.json').read_text()).items():
        if Path(name).name != name or digest(root/name) != expected:
            raise ValueError('Frozen input integrity failure')


def run(root, config, skill, call, max_new=96):
    log = root/'attempts.jsonl'
    history = rows(log)
    seen = started(log)
    results = [r for r in history if r['event'] == 'result']
    # A durable start without a result means unknown submission status: never replay.
    if seen - {r['slot'] for r in results} or any(r.get('cost') is None or r.get('protocol_error') for r in results):
        return 'blocked_by_prior_unknown_cost_or_protocol_error'
    used = sum((Decimal(r['cost']) for r in results), Decimal(0))
    tasks = {t['id']:t for t in config['tasks']}
    routes = {r['model']:r for r in config['routes']}
    count = 0
    for slot in config['slots']:
        if slot['id'] in seen:
            continue
        if count >= max_new or len(seen) >= 96:
            break
        if not can_spend(used, config['reserve_per_request'], config['budget']):
            return 'budget_stop'
        task, route = tasks[slot['task']], routes[slot['model']]
        request = payload(slot, task, route, skill)
        start = utc()
        append(log, dict(event='start', slot=slot['id'], started_at=start, payload=request,
                         reserve_usd=config['reserve_per_request']))
        monotonic = time.monotonic()
        error = None
        try:
            status, response = call(request)
        except Exception as exc:
            # Exception strings can expose credential-bearing headers; retain type only.
            status, response, error = None, {}, type(exc).__name__
        elapsed = time.monotonic() - monotonic
        usage = response.get('usage') or {}
        cost = usage.get('cost')
        if not can_spend(cost, 0, 10):
            cost = None
        choices = response.get('choices') or []
        choice = choices[0] if choices else {}
        message = choice.get('message') or {}
        finish = choice.get('finish_reason')
        protocol_error = None
        if status != 200 or response.get('error'):
            protocol_error = 'http_or_api_error'
        elif response.get('model') not in route.get('returned_models', [slot['model']]):
            protocol_error = 'model_mismatch'
        elif response.get('provider') != route['observed_provider']:
            protocol_error = 'provider_mismatch'
        elif not response.get('id') or not choices:
            protocol_error = 'malformed_response'
        result = dict(event='result', slot=slot['id'], task=slot['task'], arm=slot['arm'],
                      model_requested=slot['model'], model_returned=response.get('model'),
                      provider_requested=route['provider'], provider_observed=response.get('provider'),
                      repeat=slot['repeat'], started_at=start, ended_at=utc(), elapsed_seconds=elapsed,
                      http_status=status, error_class=error, protocol_error=protocol_error,
                      generation_id=response.get('id'), usage=usage,
                      cost=str(cost) if cost is not None else None, finish_reason=finish,
                      raw_response=response, validator_version='typed-json-v1',
                      score=score(task, message.get('content'), finish) if not protocol_error else
                      dict(status='operational_failure', reason=protocol_error))
        append(log, result)
        print(json.dumps({k:result[k] for k in ['slot','http_status','cost','protocol_error']}), flush=True)
        seen.add(slot['id'])
        count += 1
        if cost is None or protocol_error:
            return 'unknown_cost_or_protocol_error'
        used += Decimal(str(cost))
    return 'complete' if len(seen) == len(config['slots']) else 'paused'


def api(path, key, body=None, method=None):
    if not key or not key.isascii() or any(c.isspace() or ord(c)<33 for c in key):
        raise ValueError('Invalid credential')
    req = urllib.request.Request('https://openrouter.ai/api/v1/' + path,
        data=json.dumps(body).encode() if body is not None else None,
        headers={'Authorization':'Bearer '+key, 'Content-Type':'application/json'},
        method=method)
    try:
        with urllib.request.urlopen(req, timeout=180) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as exc:
        try:
            data = json.loads(exc.read())
        except ValueError:
            data = {'error':{'type':'non_json_http_error'}}
        return exc.code, data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['freeze','verify','run'])
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--max-new', type=int, default=96)
    args = parser.parse_args()
    root = args.artifacts
    if args.command == 'freeze':
        freeze(root, strict_json(args.config.read_text()))
    else:
        verify(root)
        if args.command == 'run':
            if digest(Path(__file__)) != digest(root/'bench.snapshot.py'):
                raise ValueError('Run the frozen runner, not a changed implementation')
            key = os.environ.get('TELEGRAPHIST_API_KEY', '')
            status, info = api('key', key)
            d = info.get('data', {})
            if status != 200 or d.get('limit') != 10 or d.get('is_management_key') or not can_spend(0, '0.10', d.get('limit_remaining')):
                raise ValueError('Dedicated $10 inference key preflight failed')
            config = strict_json((root/'protocol.json').read_text())
            outcome = run(root, config, (root/'SKILL.snapshot.md').read_text(),
                          lambda p:api('chat/completions', key, p), args.max_new)
            print(outcome)
            if outcome not in ('complete','paused'):
                raise SystemExit(2)


if __name__ == '__main__':
    main()
