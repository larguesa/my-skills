"""Join blinded LLM judgments without modifying candidate responses or frozen scores."""
from collections import defaultdict
from decimal import Decimal
import json
from pathlib import Path

ROOT = Path(__file__).parent
reviews = json.loads((ROOT / 'semantic-review.json').read_text())
packet = [json.loads(line) for line in (ROOT / 'blind-review.jsonl').read_text().splitlines()]
mapping = [json.loads(line) for line in (ROOT / 'blind-review-mapping.jsonl').read_text().splitlines()]
assert len(reviews) == len(packet) == len(mapping) == 48
assert len({r['review_id'] for r in reviews}) == 48
assert {r['review_id'] for r in reviews} == {r['review_id'] for r in packet} == {r['review_id'] for r in mapping}
by_review = {r['review_id']: r for r in packet}
by_slot = {m['slot']: next(r for r in reviews if r['review_id'] == m['review_id']) for m in mapping}
for r in reviews:
    assert type(r['pass']) is bool
    score = r['score']
    assert all(type(score[k]) is int and 0 <= score[k] <= cap for k, cap in [('fidelity',50),('completeness',30),('clarity',20)])
    assert score['total'] == score['fidelity'] + score['completeness'] + score['clarity']
    assert r['pass'] == (not r['critical_failures'] and not r['other_failures'])
    if 'word_count' in r:
        assert r['word_count'] == len(by_review[r['review_id']]['answer'].split())
rows = [json.loads(line) for line in (ROOT / 'attempts.jsonl').read_text().splitlines()]
results = [r for r in rows if r['event'] == 'result']
groups = defaultdict(lambda: dict(responses=0, strict_json_pass=0, strict_json_total=0,
    semantic_pass=0, semantic_total=0, semantic_critical_failures=0,
    combined_pass=0, cost_usd=Decimal(0), semantic_failures=[]))
for r in results:
    key = r['model_requested'] + '|' + r['arm']
    group = groups[key]
    group['responses'] += 1
    group['cost_usd'] += Decimal(r['cost'])
    if r['score']['status'] == 'unscored':
        review = by_slot[r['slot']]
        group['semantic_total'] += 1
        group['semantic_pass'] += review['pass']
        group['combined_pass'] += review['pass']
        group['semantic_critical_failures'] += bool(review['critical_failures'])
        if not review['pass']:
            group['semantic_failures'].append(dict(slot=r['slot'], review_id=review['review_id'], reason=review['reason']))
    else:
        group['strict_json_total'] += 1
        group['strict_json_pass'] += r['score']['status'] == 'pass'
        group['combined_pass'] += r['score']['status'] == 'pass'
for g in groups.values():
    g['combined_pass_fraction'] = g['combined_pass'] / g['responses']
    g['cost_per_combined_pass_usd'] = str(g['cost_usd'] / g['combined_pass']) if g['combined_pass'] else None
    g['cost_usd'] = str(g['cost_usd'])
summary = dict(status='generation_and_single_llm_review_complete', reviewer='gpt-6-astra via openai-codex, one blinded LLM reviewer; not human review',
    semantic_responses=48, semantic_pass=sum(r['pass'] for r in reviews),
    semantic_fail=sum(not r['pass'] for r in reviews),
    semantic_critical_failures=sum(bool(r['critical_failures']) for r in reviews),
    separate_openrouter_judge_calls=0,
    caveat='Combined pass uses strict JSON contract checks plus one subjective LLM semantic review. Not ground-truth accuracy, not human adjudication, not evidence of non-inferiority. Reviewer harness cost is not part of measured OpenRouter generation spend.',
    groups=dict(groups))
(ROOT / 'quality-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
metrics = json.loads((ROOT / 'results.json').read_text())
metrics['status'] = summary['status']
metrics['quality_assessment'] = summary
metrics['semantic_review'] = dict(status='complete_single_llm_review', reviewer=summary['reviewer'], reviewed=48, passes=summary['semantic_pass'], requirement_failures=summary['semantic_fail'], critical_violations_flagged=summary['semantic_critical_failures'], human_adjudication=False)
metrics['limitations'] = ['Single LLM semantic reviewer; no human adjudication or inter-rater study' if x == 'Free text remains unscored until explicit independent review' else x for x in metrics['limitations']]
metrics['ledger'] = json.loads((ROOT / 'accounting-summary.json').read_text())
metrics['generation_time_score_note'] = 'Existing scores/unscored fields retain the frozen deterministic validator outcome. Completed single-LLM review and combined estimates are in quality_assessment; raw logs and frozen scores are unchanged.'
(ROOT / 'results.json').write_text(json.dumps(metrics, ensure_ascii=False, indent=2))
print(json.dumps(summary, ensure_ascii=False, indent=2))
